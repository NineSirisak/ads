# CKTONLINE Enterprise Master Blueprint

เอกสารนี้เป็นการรวมแนวคิดเดิมและเอกสารฉบับสมบูรณ์เข้าด้วยกัน

## วิสัยทัศน์
- ระบบโลจิสติกส์แบบ Paperless
- รองรับ SuperAdmin / Admin / Driver
- PWA รองรับ Offline
- OCR + Anti-Fraud + COD
- Dashboard และ Reporting

## Modules
- Authentication (JWT/RBAC/MFA)
- Driver PWA
- Admin Dashboard
- SuperAdmin Analytics
- OCR Pipeline
- COD Workflow
- Approval Workflow
- Notification (LINE/Push/Email/In-app)
- GPS Tracking
- Offline Sync
- Audit Log
- Report Engine
- Auto Delete 15 วัน
- Data Retention 45 วัน

## Architecture
Frontend: Next.js PWA
Backend: REST API
Database: PostgreSQL/Supabase
Storage: Object Storage
Realtime: Supabase
Queue: OCR Worker
Deploy: Vercel

## Database
users, roles, permissions, drivers, vehicles, warehouses,
jobs, bookings, checkins, deliveries, ocr_results,
cod_transactions, advance_requests, notifications,
audit_logs, activity_logs, files, settings

## Security
- RLS
- Append-only logs
- Signed URL
- Audit Trail
- Attempt Limiting
- OCR Confidence Review

## Roadmap
1. Branding/UI
2. Core Infrastructure
3. Driver & OCR
4. Admin Dashboard
5. SuperAdmin Analytics
6. Testing/UAT
7. Deployment
8. Continuous Improvement
